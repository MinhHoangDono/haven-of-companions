Low Poly Hex Terrain Kit v1.0.1 - Standard edition
=================================================

FREE (name your own price, from $0): 30 hand-picked pieces (20 hex tiles + 10 trees / rocks / plants, spring colors), GLB / FBX / OBJ - enough for a small hex map with a coast, a river, a road, hills and a mountain.

Low poly HEX terrain for strategy, 4X, tactics, board-game and RPG prototypes - and for renders.
Flat-top hexagons with 2 m edges (4 m corner to corner): ground and fields, real height levels (every tile has its
own 2 m rock cliff, rock columns stack it higher), ramps and stairs, hills, mountains, a volcano, coasts, rivers,
waterfalls, roads, paths, bridges and fords - plus forests (one-cell groves), trees, rocks, plants and props.
Four seasons from one shared palette.
Part of the "Amano Props" series: same palette, same scale and the same decorations as the square Terrain Kit
(https://amano007.itch.io/low-poly-terrain-kit). 75 of the 84 decorations are the same models as in the square Terrain Kit.

CONTENTS
  Models/GLB/        glTF binary, spring colors (recommended: Godot 4, Unity with glTFast, Unreal 5, Three.js)
  Models/FBX/        FBX (Unity, Unreal, Blender) - the palette texture sits next to the models and loads automatically
  Models/OBJ/        OBJ + MTL (the .mtl points to Textures/props_palette.png)
  Textures/          props_palette.png (128x256 color palette) + props_emission.png (glow map)
  Docs/              Hex_Guide.txt, STYLE_GUIDE.txt, Palette_Chart.png, tiles.json (edge sockets)

CHANGELOG
  1.0.1  OBJ + FBX: textures load automatically (palette next to the FBX files, .mtl paths to Textures/)
  1.0.0  initial release: 174 pieces in Complete / Pro (90 hex tiles + 84 decorations), 4 seasons

SPECS
  - Scale: 1 unit = 1 meter. Flat-top hexagon, edge 2 m: 4.0 m corner to corner (X), 3.464 m side to side (Y).
    Origin at the tile centre, the walkable surface is at height 0. One level = 2 m.
  - Grid (axial coordinates q, r): x = 3.0 * q ; y = 3.4641 * (r + q / 2). Rotations by 60 degree steps.
    For pointy-top hexagons, rotate every tile by 90 degrees (and swap the grid formula's axes).
  - Every tile has a closed rock skirt 2.25 m deep: raise a tile by 2 m and it shows its own cliff, whatever
    its neighbours. Higher: put Hex_Rock_Column (2 m) or Hex_Rock_Column_4m under it.
  - Widths: road 1.2 m, path 0.8 m, river 1.0 m. Water surface at -0.2 m (opaque, colored).
  - Ramps climb 2 m over one cell (30 degrees). Waterfalls: the curtain is on the NORTH edge of the lower tile.
  - Tile edges are exactly identical between compatible tiles: see Docs/tiles.json ("sockets", 6 per tile).
  - Models are Z-up in Blender and exported Y-up (glTF / FBX / OBJ).
  - One shared material / one 128 x 256 palette texture for the whole pack. Use NEAREST (point) filtering.
    Alternative seasons: Textures/props_palette_autumn.png, _snow.png, _desert.png (same UVs: swap the image) and the
    ready-made Models/GLB_Autumn, GLB_Snow, GLB_Desert folders (Complete / Pro).
  - FBX: the palette is next to the .fbx files (and in Textures/). OBJ: the .mtl points to Textures/.
  - Flame and lava colors use the emission map props_emission.png (optional).
  - Faces: 193 for a plain grass tile, up to 857 per tile; the 169-cell example map is about 79,000 faces.

TILE ORIENTATION (as imported)
  Edges counter-clockwise from the top: 0 NE, 1 N, 2 NW, 3 SW, 4 S (front, -Y), 5 SE.
  Rivers, roads and paths always use the south edge (4). Straight: S-N. Bend_Wide: S-NE. Bend_Tight: S-SE.
  Ramps, stairs and rapids climb toward the NORTH. Coast_N: water on the south side first (S, then SE, SW...).
  See Docs/Hex_Guide.txt for levels, ramps, waterfalls and the 13 connection patterns.

ASSETS (30)
  [Ground] Hex_Grass_A  (193 faces)
  [Ground] Hex_Grass_B  (193 faces)
  [Ground] Hex_Dirt  (193 faces)
  [Ground] Hex_Sand  (193 faces)
  [Water] Hex_Water  (193 faces)
  [Water] Hex_Coast_1  (577 faces)
  [Water] Hex_Coast_2  (577 faces)
  [Water] Hex_Coast_3  (577 faces)
  [Rivers] Hex_River_Source  (577 faces)
  [Rivers] Hex_River_Straight  (577 faces)
  [Rivers] Hex_River_Bend_Wide  (577 faces)
  [Rivers] Hex_River_Bend_Tight  (577 faces)
  [Roads] Hex_Road_End  (577 faces)
  [Roads] Hex_Road_Straight  (577 faces)
  [Roads] Hex_Road_Bend_Wide  (577 faces)
  [Roads] Hex_Road_Bend_Tight  (577 faces)
  [Roads] Hex_Road_Y  (577 faces)
  [Hills] Hex_Hill_Small  (577 faces)
  [Hills] Hex_Mountain_A  (577 faces)
  [Slopes] Hex_Ramp_Grass  (625 faces)
  [Trees] Tree_Pine_A  (40 faces)
  [Trees] Tree_Pine_C  (32 faces)
  [Trees] Tree_Oak_A  (104 faces)
  [Groves] Grove_Pines  (188 faces)
  [Rocks] Rock_A  (20 faces)
  [Rocks] Rock_B  (20 faces)
  [Rocks] Rock_Large  (80 faces)
  [Plants] Bush_A  (60 faces)
  [Plants] Grass_Tuft_A  (36 faces)
  [Plants] Flowers_Mixed  (260 faces)

LICENSE
  See LICENSE.txt. You may use these assets in personal and commercial projects.
  You may not resell or redistribute the assets themselves, even modified.
