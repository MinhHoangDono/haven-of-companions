﻿extends Node3D
## Low Poly World Builder v1 (Godot 4.7) - Amano007 - Low Poly World Collection
## Le monde de demonstration est un fichier de sauvegarde (data/monde_defaut.json) charge au demarrage.
## Les modeles sont charges a la demande (jamais les 1 856 d'un coup).
## Test sans fenetre :  godot --headless --path . -- --test
## Captures :           godot --path . -- --shots   (dossier : variable d'environnement SHOTS_DIR)

const AMBIANCES := ["day", "night", "pastel", "winter", "sunset"]
const AMB_NOMS := {"day": "Jour", "night": "Nuit", "pastel": "Pastel", "winter": "Hiver", "sunset": "Coucher de soleil"}
const PACK_NOMS := {"town": "Town Starter", "terrain": "Terrain", "hex": "Terrain Hex", "interiors": "Interiors",
	"garage": "Garage", "laverie": "Laverie", "halloween": "Halloween", "route66": "Route 66", "bazar": "Bazar"}
const TILE := 4.0
# variantes de palette du sol (aides de rendu generees par tools/palette_sol_sec.py, palettes des packs inchangees) :
# dry1..dry8 = degrade herbe verte -> herbe seche -> sable chaud terne ; route66 dry = desert Route 66 assorti
const MV_LIST := {"terrain": ["autumn", "desert", "dry", "dry1", "dry2", "dry3", "dry4", "dry5", "dry6", "dry7", "dry8"],
	"route66": ["dry"]}
const HA := 1.7320508075688772
const DEMO := "res://data/monde_defaut.json"
const SAVE := "user://mon_monde.json"
# nom, cible, distance, inclinaison, orientation
const ZONES_ALL := [
	["Ville", Vector3(2, 0, 4), 78.0, -42.0, 35.0],
	["Autoroute vers Route 66", Vector3(76, 0, 0), 70.0, -30.0, 20.0],
	["Route 66 Desert Stop", Vector3(140, 0, 0), 72.0, -38.0, 30.0],
	["Autoroute vers le Bazar", Vector3(0, 0, 76), 70.0, -30.0, 110.0],
	["Bazar (ville arabe)", Vector3(0, 0, 132), 66.0, -36.0, 150.0],
	["Ile hexagonale", Vector3(-132, 0, 0), 58.0, -48.0, 20.0],
	["Halloween", Vector3(0, 0, -88), 42.0, -38.0, 20.0],
	["Showroom", Vector3(-54, 0, -52), 34.0, -40.0, 0.0],
]
# ciel haut, horizon, nuages, soleil (couleur, energie, inclinaison, orientation), ambiance (couleur, energie),
# exposition, brouillard (couleur, densite), glow (intensite, seuil), saturation, contraste, emission
const LUM := {
	"day": [Color(0.10, 0.40, 0.95), Color(0.55, 0.78, 1.0), Color(1, 1, 1), Color(1.0, 0.88, 0.68), 2.1, -38.0, -50.0,
		Color(0.60, 0.62, 0.70), 0.75, 0.85, Color(0.62, 0.78, 1.0), 0.00012, 0.12, 1.8, 1.3, 1.25, 1.0],
	"night": [Color(0.02, 0.025, 0.055), Color(0.15, 0.14, 0.19), Color(0.2, 0.2, 0.25), Color(0.80, 0.82, 0.92), 0.5, -55.0, 30.0,
		Color(0.42, 0.41, 0.46), 0.8, 1.1, Color(0.13, 0.12, 0.16), 0.0010, 0.9, 0.95, 1.05, 1.12, 2.6],
	"pastel": [Color(0.50, 0.68, 0.95), Color(0.98, 0.87, 0.90), Color(1, 0.97, 0.98), Color(1.0, 0.94, 0.90), 1.75, -40.0, -45.0,
		Color(0.76, 0.72, 0.80), 0.82, 0.9, Color(0.95, 0.86, 0.92), 0.0004, 0.2, 1.5, 1.05, 1.1, 1.0],
	"winter": [Color(0.40, 0.58, 0.82), Color(0.86, 0.91, 0.97), Color(1, 1, 1), Color(0.96, 0.97, 1.0), 1.7, -28.0, -50.0,
		Color(0.72, 0.77, 0.86), 0.85, 0.85, Color(0.86, 0.9, 0.96), 0.0009, 0.2, 1.5, 1.05, 1.15, 1.1],
	"sunset": [Color(0.16, 0.20, 0.48), Color(1.0, 0.56, 0.32), Color(1.0, 0.78, 0.62), Color(1.0, 0.62, 0.36), 1.9, -13.0, -72.0,
		Color(0.70, 0.52, 0.52), 0.62, 0.95, Color(1.0, 0.62, 0.45), 0.0007, 0.45, 1.2, 1.2, 1.2, 1.5],
}

var ZONES: Array = ZONES_ALL
var palier: Dictionary = {}
var cat: Array = []
var by_id: Dictionary = {}
var packs: Array = []
var pal_map: Dictionary = {}
var scenes: Dictionary = {}
var mats: Dictionary = {}
var ghost_mats: Dictionary = {}
var mesh_cache: Dictionary = {}
var placed: Array = []
var tile_at: Dictionary = {}
var undo_stack: Array = []
var redo_stack: Array = []
var missing: Array = []
var ambiance := "day"
var light_mode := false
var snap_half := false
var current: Dictionary = {}
var rot := 0.0
var drag_action: Dictionary = {}
var testing := false
var loading := false
var load_ms := 0

var pieces_root: Node3D
var ghost: Node3D = null
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ShaderMaterial
var cam_target := Vector3(2, 0, 4)
var cam_yaw := 35.0
var cam_pitch := -42.0
var cam_dist := 78.0
var orbit_drag := false
var pan_drag := false
var last_tint_target := Vector3(1e9, 0, 0)

var layer: CanvasLayer
var panel: PanelContainer
var search_edit: LineEdit
var pack_opt: OptionButton
var cat_opt: OptionButton
var item_list: ItemList
var info_label: Label
var status_label: Label
var help_label: Label
var load_label: Label
var zone_opt: OptionButton
var cur_cats: Array = []


func _ready() -> void:
	var args := OS.get_cmdline_user_args()
	testing = "--test" in args
	cat = JSON.parse_string(FileAccess.get_file_as_string("res://data/catalogue.json"))
	# palier (Standard / Complete / Pro) : data/palier.json absent = projet complet (1 856 pieces)
	if FileAccess.file_exists("res://data/palier.json"):
		palier = JSON.parse_string(FileAccess.get_file_as_string("res://data/palier.json"))
		var zs: Array = []
		for zi in palier.get("zones", range(ZONES_ALL.size())):
			zs.append(ZONES_ALL[int(zi)])
		ZONES = zs
	pal_map = JSON.parse_string(FileAccess.get_file_as_string("res://data/palette_map.json"))
	for e in cat:
		by_id[e["id"]] = e
		if not packs.has(e["pack"]):
			packs.append(e["pack"])
	pieces_root = Node3D.new()
	pieces_root.name = "Pieces"
	add_child(pieces_root)
	_setup_environment()
	_make_materials()
	_make_base_ground()
	_make_horizon()
	_setup_camera()
	_build_ui()
	set_ambiance("day")
	_update_camera()
	var t0 := Time.get_ticks_msec()
	await load_world(DEMO)
	load_ms = Time.get_ticks_msec() - t0
	print("Monde charge : %d pieces, %d modeles en memoire sur %d, %.1f s" % [placed.size(), scenes.size(), cat.size(), load_ms / 1000.0])
	if testing:
		await _run_tests()
	elif "--shots" in args:
		await _run_shots()


# ---------------------------------------------------------------- materiaux (un par pack, partage)
func _tex(path: String) -> Texture2D:
	return load(path) as Texture2D


func _make_materials() -> void:
	for p in packs:
		var m := StandardMaterial3D.new()
		m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST_WITH_MIPMAPS
		m.roughness = 0.8
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
		m.emission_enabled = true
		mats[p] = m
		var g := StandardMaterial3D.new()
		g.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		g.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		g.albedo_color = Color(1, 1, 1, 0.5)
		g.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		ghost_mats[p] = g
	for p in MV_LIST:
		if not mats.has(p):
			continue
		for v in MV_LIST[p]:
			var mv := (mats[p] as StandardMaterial3D).duplicate() as StandardMaterial3D
			mats[p + "|" + v] = mv


func _mat_for(pack: String, mv: String) -> StandardMaterial3D:
	if mv != "" and mats.has(pack + "|" + mv):
		return mats[pack + "|" + mv]
	return mats[pack]


func _apply_materials_for(a: String) -> void:
	var emis: float = LUM[a][16]
	for p in packs:
		var m: StandardMaterial3D = mats[p]
		m.albedo_texture = _tex("res://palettes/%s/palette_%s.png" % [p, a])
		m.emission_texture = _tex("res://palettes/%s/emission_%s.png" % [p, a])
		var info: Dictionary = pal_map[p][a]
		# palette generee (approximation) : l'emission d'origine est renforcee pour rester lisible
		var boost := 1.0
		if info["palette"] == "auto" and a == "sunset":
			boost = 1.35
		m.emission_energy_multiplier = emis * boost
		(ghost_mats[p] as StandardMaterial3D).albedo_texture = m.albedo_texture
	for p in MV_LIST:
		if not mats.has(p):
			continue
		for v in MV_LIST[p]:
			var mv: StandardMaterial3D = mats[p + "|" + v]
			mv.albedo_texture = _tex("res://palettes/%s/palette_%s_%s.png" % [p, a, v])
			mv.emission_texture = (mats[p] as StandardMaterial3D).emission_texture
			mv.emission_energy_multiplier = (mats[p] as StandardMaterial3D).emission_energy_multiplier
	if base_ground != null:
		_color_base_ground(a)
	if horizon != null:
		_color_horizon(a)


# ---------------------------------------------------------------- decor : ciel, lumiere, sol de fond
func _setup_environment() -> void:
	var sh := Shader.new()
	sh.code = """
shader_type sky;
uniform vec3 top : source_color = vec3(0.10, 0.40, 0.95);
uniform vec3 horizon : source_color = vec3(0.55, 0.78, 1.0);
uniform vec3 cloud : source_color = vec3(1.0);
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
	vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
	return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) { float v = 0.0; float a = 0.5; for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.0; a *= 0.5; } return v; }
void sky() {
	vec3 d = EYEDIR;
	float t = clamp(d.y, 0.0, 1.0);
	vec3 col = mix(horizon, top, pow(t, 0.55));
	if (d.y > 0.02) {
		vec2 uv = d.xz / (d.y + 0.3) * 1.4;
		float c = smoothstep(0.50, 0.74, fbm(uv));
		col = mix(col, cloud, c * smoothstep(0.02, 0.22, d.y));
	}
	if (d.y < 0.0) { col = horizon * 0.92; }
	COLOR = col;
}
"""
	sky_mat = ShaderMaterial.new()
	sky_mat.shader = sh
	var sky := Sky.new()
	sky.sky_material = sky_mat
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.ssao_enabled = true
	env.ssao_radius = 1.2
	env.ssao_intensity = 4.0
	env.glow_enabled = true
	env.glow_bloom = 0.03
	env.fog_enabled = true
	env.fog_sky_affect = 0.0
	env.adjustment_enabled = true
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.light_angular_distance = 1.2
	sun.shadow_enabled = true
	sun.shadow_blur = 1.5
	sun.directional_shadow_max_distance = 120.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)


func _apply_light(a: String, tint_r: float = 0.0, tint_b: float = 0.0) -> void:
	var c: Array = LUM[a]
	var top: Color = c[0]
	var hor: Color = c[1]
	var sun_col: Color = c[3]
	var sun_pitch: float = c[5]
	var fog_col: Color = c[10]
	if a == "day":
		# ambiance des deserts : chaude vers la Route 66, coucher de soleil rouge vers le Bazar
		# Bazar : ambiance chaude SANS violet (un haut bleu sature melange a un horizon orange donnait du lilas) :
		# haut de ciel plus clair et un peu vert-bleu, horizon sable, brume doree
		hor = hor.lerp(Color(0.98, 0.86, 0.68), tint_r * 0.8).lerp(Color(0.99, 0.86, 0.64), tint_b * 0.8)
		top = top.lerp(Color(0.22, 0.45, 0.85), tint_r * 0.6).lerp(Color(0.34, 0.62, 0.86), tint_b * 0.75)
		sun_col = sun_col.lerp(Color(1.0, 0.80, 0.55), tint_r).lerp(Color(1.0, 0.70, 0.44), tint_b)
		sun_pitch = lerpf(sun_pitch, -24.0, tint_b)
		fog_col = fog_col.lerp(Color(0.98, 0.85, 0.68), tint_r).lerp(Color(0.98, 0.80, 0.58), tint_b)
	sky_mat.set_shader_parameter("top", top)
	sky_mat.set_shader_parameter("horizon", hor)
	sky_mat.set_shader_parameter("cloud", c[2])
	sun.light_color = sun_col
	sun.light_energy = c[4]
	sun.rotation_degrees = Vector3(sun_pitch, c[6], 0)
	env.ambient_light_color = c[7]
	env.ambient_light_energy = c[8]
	env.tonemap_exposure = c[9]
	env.fog_light_color = fog_col
	env.fog_density = c[11]
	env.glow_intensity = c[12]
	env.glow_hdr_threshold = c[13]
	env.adjustment_saturation = c[14]
	env.adjustment_contrast = c[15]


func _desert_weights(p: Vector3) -> Vector2:
	var r := smoothstep(50.0, 110.0, p.x) * (1.0 - smoothstep(35.0, 70.0, absf(p.z)))
	var b := smoothstep(50.0, 110.0, p.z) * (1.0 - smoothstep(45.0, 80.0, absf(p.x)))
	return Vector2(r, b)


var base_ground: MeshInstance3D = null


func _color_base_ground(a: String) -> void:
	var arr := base_ground.mesh.surface_get_arrays(0)
	var verts: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	var cols := PackedColorArray()
	cols.resize(verts.size())
	for i in verts.size():
		cols[i] = _ground_color(verts[i].x, verts[i].z, a)
	arr[Mesh.ARRAY_COLOR] = cols
	var nm := ArrayMesh.new()
	nm.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	base_ground.mesh = nm


func _make_base_ground() -> void:
	# sol de fond (aide au rendu, PAS dans les packs) : vert au nord-ouest, sable vers les deserts, mer autour de l'ile hex
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var step := 10.0     # 10 m : rive du lac nette (en 20 m, le degrade eau -> sol faisait un halo jaune)
	var n := 112
	var x0 := -540.0
	for i in n:
		for j in n:
			var quad := [Vector2(i, j), Vector2(i + 1, j), Vector2(i + 1, j + 1), Vector2(i, j), Vector2(i + 1, j + 1), Vector2(i, j + 1)]
			for q in quad:
				var x: float = x0 + q.x * step
				var z: float = x0 + q.y * step
				st.set_color(_ground_color(x, z, "day"))
				st.set_normal(Vector3.UP)
				st.add_vertex(Vector3(x, -0.3, z))
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 1.0
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	mi.name = "SolDeFond"
	add_child(mi)
	base_ground = mi


func _ground_color(x: float, z: float, a: String = "day") -> Color:
	# vert -> herbe seche olive -> sable beige peu sature (assorti aux tuiles : herbe seche, sable Terrain, desert Route 66)
	var green := Color(0.25, 0.42, 0.15)
	var dry := Color(0.48, 0.48, 0.33)
	var sand := Color(0.57, 0.50, 0.39)     # assorti au sable des tuiles (palettes « dry » du World Builder)
	if a == "winter":
		green = Color(0.86, 0.89, 0.93)
		dry = Color(0.85, 0.88, 0.91)
		sand = Color(0.84, 0.86, 0.88)
	var des := _desert_at(x, z)
	var c := green.lerp(dry, clampf(des * 2.0, 0.0, 1.0)).lerp(sand, clampf(des * 2.0 - 1.0, 0.0, 1.0))
	if a != "winter":
		# taches de terre plus brune / de sable plus gris dans le desert (sol varie, pas un aplat)
		var v := sin(x * 0.019 + 0.4) * cos(z * 0.023 + 1.1) + 0.5 * sin((x + z) * 0.041)
		c = c.lerp(Color(0.58, 0.48, 0.36) if v > 0.0 else Color(0.62, 0.57, 0.46), minf(absf(v), 1.0) * 0.15 * des)
	# variation douce (pas d'aplat) + mer autour de l'ile hex + brume vers l'horizon
	c = c * (0.9 + 0.1 * sin(x * 0.031 + 1.3) * cos(z * 0.027 - 0.7))
	var dh := Vector2(x + 132.0, z).length()
	if dh < 104.0 and a != "winter":
		# rive : vert-bleu sombre (pas de bande jaune / olive claire entre l'eau et le sol)
		c = c.lerp(Color(0.16, 0.33, 0.28), clampf((104.0 - dh) / 7.0, 0.0, 1.0))
	if dh < 95.0:
		c = c.lerp(Color(0.14, 0.40, 0.55) * (0.93 + 0.07 * sin(x * 0.2) * sin(z * 0.17)), clampf((95.0 - dh) / 4.0, 0.0, 1.0))
	c = c.lerp(_haze_color(x, z, a), smoothstep(240.0, 470.0, Vector2(x - 10.0, z - 40.0).length()) * 0.8)
	if a == "night":
		c = c * Color(0.16, 0.16, 0.19)
	elif a == "sunset":
		c = c * Color(0.95, 0.72, 0.6)
	elif a == "pastel":
		c = c.lerp(Color(0.95, 0.88, 0.92), 0.25)
	return c


func _haze_color(x: float, z: float, a: String) -> Color:
	# couleur de brume d'horizon : bleu ciel au nord-ouest, chaude vers les deserts (avant teinte de l'ambiance)
	var d := Vector2(x - 10.0, z - 40.0).normalized()
	# chaud seulement dans le secteur des deserts (sud-est), bleu-gris clair ailleurs (pas de grand aplat orange)
	var warm := smoothstep(0.35, 1.25, d.x + d.y)
	var c := Color(0.70, 0.78, 0.88).lerp(Color(0.90, 0.80, 0.66), warm)
	if a == "winter":
		c = Color(0.86, 0.90, 0.96)
	return c


# ---------------------------------------------------------------- horizon (aide au rendu, PAS des modeles des packs)
var horizon: MeshInstance3D = null
var peaks: Array = []


func _make_horizon() -> void:
	# anneau de montagnes et de buttes low poly tres lointaines (150 a 400 m du bord du monde) : UN seul maillage
	var r := RandomNumberGenerator.new()
	r.seed = 66
	var n := 120
	for k in n:
		var ang := (k + r.randf_range(-0.3, 0.3)) / float(n) * TAU
		var far := k % 2 == 1
		var dist := r.randf_range(330.0, 400.0) if far else r.randf_range(255.0, 300.0)
		var dir := Vector2(cos(ang), sin(ang))
		var ctr := Vector2(10.0, 40.0) + dir * dist
		var desert := clampf((dir.x + dir.y) * 1.1, 0.0, 1.0)
		var mesa := desert > 0.45 and r.randf() < 0.75
		var h := r.randf_range(18.0, 42.0) if mesa else r.randf_range(26.0, 78.0) * (1.25 if far else 1.0)
		var rad := r.randf_range(34.0, 62.0)
		peaks.append({"c": ctr, "h": h, "r": rad, "mesa": mesa, "desert": desert, "far": far,
			"sides": r.randi_range(5, 7), "rot": r.randf() * TAU, "jit": [r.randf(), r.randf(), r.randf(), r.randf(), r.randf(), r.randf(), r.randf()],
			"ax": r.randf_range(-0.25, 0.25), "az": r.randf_range(-0.25, 0.25)})
	horizon = MeshInstance3D.new()
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.vertex_color_is_srgb = true
	mat.roughness = 1.0
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED  # ombrage deja calcule dans les couleurs
	horizon.material_override = mat
	horizon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	horizon.name = "HorizonMontagnes"
	add_child(horizon)
	_color_horizon("day")


func _color_horizon(a: String) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for p in peaks:
		var ctr: Vector2 = p["c"]
		var h: float = p["h"]
		var rad: float = p["r"]
		var sides: int = p["sides"]
		var jit: Array = p["jit"]
		var base: Array = []
		var top: Array = []
		for i in sides:
			var an: float = p["rot"] + i / float(sides) * TAU
			var rr: float = rad * (0.75 + 0.5 * float(jit[i]))
			base.append(Vector3(ctr.x + cos(an) * rr, -1.0, ctr.y + sin(an) * rr))
			if p["mesa"]:
				top.append(Vector3(ctr.x + cos(an) * rr * 0.62, h, ctr.y + sin(an) * rr * 0.62))
		var apex := Vector3(ctr.x + rad * float(p["ax"]), h, ctr.y + rad * float(p["az"]))
		var col_low: Color
		var col_high: Color
		if p["mesa"]:
			col_low = Color(0.74, 0.40, 0.24)
			col_high = Color(0.66, 0.30, 0.20)
		else:
			col_low = Color(0.30, 0.44, 0.26).lerp(Color(0.62, 0.52, 0.36), float(p["desert"]))
			col_high = Color(0.50, 0.52, 0.55) if h < 70.0 else Color(0.92, 0.94, 0.97)
		if a == "winter" and not p["mesa"]:
			col_low = Color(0.82, 0.86, 0.90)
			col_high = Color(0.95, 0.96, 0.98)
		var hz := _haze_color(ctr.x, ctr.y, a)
		var fade := 0.52 if p["far"] else 0.34
		for i in sides:
			var b0: Vector3 = base[i]
			var b1: Vector3 = base[(i + 1) % sides]
			if p["mesa"]:
				var t0: Vector3 = top[i]
				var t1: Vector3 = top[(i + 1) % sides]
				_tri(st, b0, t0, b1, col_low, hz, fade, a)
				_tri(st, b1, t0, t1, col_low, hz, fade, a)
				_tri(st, t0, Vector3(ctr.x, h, ctr.y), t1, col_high, hz, fade, a)
			else:
				var mid0 := b0.lerp(apex, 0.45)
				var mid1 := b1.lerp(apex, 0.45)
				_tri(st, b0, mid0, b1, col_low, hz, fade, a)
				_tri(st, b1, mid0, mid1, col_low, hz, fade, a)
				_tri(st, mid0, apex, mid1, col_high, hz, fade, a)
	horizon.mesh = st.commit()
	_build_far_decor(a)


# ---------------------------------------------------------------- arriere-plan proche (aide au rendu, PAS des modeles des packs)
# collines basses, bosquets de sapins tres simples et rochers poses sur le sol de fond entre le monde et les montagnes,
# pour casser le grand aplat vert / sable. Un seul maillage (~6 000 triangles), cache en mode leger.
var far_decor: MeshInstance3D = null
var far_items: Array = []
const OCCUPE := [[-74.0, 74.0, -74.0, 74.0], [68.0, 202.0, -62.0, 62.0], [-70.0, 86.0, 68.0, 188.0],
	[-46.0, 46.0, -138.0, -62.0]]


func _far_free(x: float, z: float, marge: float) -> bool:
	for rc in OCCUPE:
		if x > rc[0] - marge and x < rc[1] + marge and z > rc[2] - marge and z < rc[3] + marge:
			return false
	return Vector2(x + 132.0, z).length() > 100.0 + marge   # mer de l'ile hex


func _make_far_items() -> void:
	var r := RandomNumberGenerator.new()
	r.seed = 2027
	var tries := 0
	while far_items.size() < 230 and tries < 6000:
		tries += 1
		var ang := r.randf() * TAU
		var dist := r.randf_range(95.0, 330.0)
		var x := 10.0 + cos(ang) * dist
		var z := 40.0 + sin(ang) * dist
		var kind := r.randi_range(0, 2)   # 0 colline, 1 bosquet, 2 rochers
		var rad := r.randf_range(14.0, 34.0) if kind == 0 else r.randf_range(5.0, 11.0)
		if not _far_free(x, z, rad + 6.0):
			continue
		far_items.append({"x": x, "z": z, "k": kind, "r": rad, "h": r.randf_range(0.12, 0.3) * rad,
			"rot": r.randf() * TAU, "n": r.randi_range(4, 9), "s": r.randi()})


func _desert_at(x: float, z: float) -> float:
	# sable vers l'est (Route 66) et le sud (Bazar) et entre les deux ; redevient vert au nord-est et au sud-ouest
	var e := clampf((x - 40.0) / 64.0, 0.0, 1.0) if x > 34.0 else 0.0
	var s := clampf((z - 40.0) / 64.0, 0.0, 1.0) if z > 34.0 else 0.0
	e *= 1.0 - smoothstep(70.0, 150.0, -z)
	s *= 1.0 - smoothstep(75.0, 155.0, -x)
	return maxf(e, s)


func _build_far_decor(a: String) -> void:
	if far_items.is_empty():
		_make_far_items()
	if far_decor == null:
		far_decor = MeshInstance3D.new()
		var mat := StandardMaterial3D.new()
		mat.vertex_color_use_as_albedo = true
		mat.vertex_color_is_srgb = true
		mat.roughness = 1.0
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		far_decor.material_override = mat
		far_decor.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		far_decor.name = "DecorLointain"
		add_child(far_decor)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var r := RandomNumberGenerator.new()
	for it in far_items:
		r.seed = int(it["s"])
		var x: float = it["x"]
		var z: float = it["z"]
		var g := _ground_color(x, z, a)
		var des := _desert_at(x, z)
		if it["k"] == 0:
			# colline / dune : base a 9 cotes, anneau a mi-hauteur, sommet ; couleur du sol (un peu plus sombre a l'ombre)
			var rad: float = it["r"]
			var h: float = it["h"] * (0.6 if des > 0.5 else 1.0)
			var n := 9
			var ring0: Array = []
			var ring1: Array = []
			for i in n:
				var an: float = it["rot"] + i / float(n) * TAU
				var rr := rad * r.randf_range(0.8, 1.15)
				ring0.append(Vector3(x + cos(an) * rr, -0.4, z + sin(an) * rr * 0.75))
				ring1.append(Vector3(x + cos(an) * rr * 0.55, h * 0.72, z + sin(an) * rr * 0.55 * 0.75))
			var top := Vector3(x + r.randf_range(-0.15, 0.15) * rad, h, z)
			for i in n:
				var j := (i + 1) % n
				_lit_tri(st, ring0[i], ring1[i], ring0[j], g)
				_lit_tri(st, ring0[j], ring1[i], ring1[j], g)
				_lit_tri(st, ring1[i], top, ring1[j], g)
		elif it["k"] == 1 and des < 0.35:
			# bosquet : sapins coniques (6 cotes) ; verts fonces, plus clairs au loin (brume)
			var leaf := Color(0.14, 0.32, 0.14).lerp(g, 0.35)
			if a == "winter":
				leaf = Color(0.55, 0.62, 0.60)
			elif a == "night":
				leaf = g * 0.9
			for t in int(it["n"]):
				var ox := x + r.randf_range(-1.0, 1.0) * float(it["r"])
				var oz := z + r.randf_range(-1.0, 1.0) * float(it["r"])
				var hh := r.randf_range(5.0, 10.0)
				var rr := hh * 0.32
				var apex := Vector3(ox, hh, oz)
				for i in 6:
					var a0 := i / 6.0 * TAU
					var a1 := (i + 1) / 6.0 * TAU
					_lit_tri(st, Vector3(ox + cos(a0) * rr, 0.6, oz + sin(a0) * rr), apex, Vector3(ox + cos(a1) * rr, 0.6, oz + sin(a1) * rr), leaf)
		else:
			# rochers (rouges dans le desert, gris ailleurs)
			var rock := Color(0.48, 0.47, 0.45).lerp(Color(0.62, 0.36, 0.24), des).lerp(g, 0.25)
			if a == "night":
				rock = g * 1.1
			elif a == "winter":
				rock = Color(0.70, 0.72, 0.75)
			for t in maxi(2, int(it["n"]) / 2):
				var ox := x + r.randf_range(-1.0, 1.0) * float(it["r"])
				var oz := z + r.randf_range(-1.0, 1.0) * float(it["r"])
				var hh := r.randf_range(1.5, 5.0)
				var rr := hh * r.randf_range(0.8, 1.4)
				var apex := Vector3(ox + r.randf_range(-0.3, 0.3) * rr, hh, oz)
				for i in 5:
					var a0 := i / 5.0 * TAU + float(t)
					var a1 := (i + 1) / 5.0 * TAU + float(t)
					_lit_tri(st, Vector3(ox + cos(a0) * rr, -0.3, oz + sin(a0) * rr), apex, Vector3(ox + cos(a1) * rr, -0.3, oz + sin(a1) * rr), rock)
	far_decor.mesh = st.commit()


func _lit_tri(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3, col: Color) -> void:
	var nrm := (p1 - p0).cross(p2 - p0).normalized()
	if nrm.y < 0.0:
		nrm = -nrm
		var tmp := p1
		p1 = p2
		p2 = tmp
	# Godot : face avant = sens horaire vue de dehors -> on emet p0, p2, p1 (sinon face arriere, normale inversee, tout noir)
	for v in [p0, p2, p1]:
		st.set_color(col)
		st.set_normal(nrm)
		st.add_vertex(v)


func _tri(st: SurfaceTool, p0: Vector3, p1: Vector3, p2: Vector3, col: Color, hz: Color, fade: float, a: String) -> void:
	var nrm := (p1 - p0).cross(p2 - p0).normalized()
	if nrm.y < 0.0:
		nrm = -nrm
		var tmp := p1
		p1 = p2
		p2 = tmp
	var shade := 0.72 + 0.28 * clampf(nrm.dot(Vector3(0.45, 0.75, 0.5).normalized()), 0.0, 1.0)
	var c := (col * shade).lerp(hz, fade)
	if a == "night":
		c = c * Color(0.14, 0.14, 0.18)
	elif a == "sunset":
		c = c * Color(0.95, 0.70, 0.6)
	elif a == "pastel":
		c = c.lerp(Color(0.95, 0.88, 0.92), 0.25)
	for v in [p0, p1, p2]:
		st.set_color(c)
		st.set_normal(nrm)
		st.add_vertex(v)


# ---------------------------------------------------------------- camera
func _setup_camera() -> void:
	cam = Camera3D.new()
	cam.far = 900.0
	cam.fov = 55.0
	cam.current = true
	add_child(cam)


func _update_camera() -> void:
	var b := Basis(Vector3.UP, deg_to_rad(cam_yaw)) * Basis(Vector3.RIGHT, deg_to_rad(cam_pitch))
	cam.position = cam_target + b * Vector3(0, 0, cam_dist)
	cam.look_at(cam_target, Vector3.UP)
	if ambiance == "day" and cam_target.distance_to(last_tint_target) > 2.0:
		last_tint_target = cam_target
		var w := _desert_weights(cam_target)
		_apply_light("day", w.x, w.y)


func go_zone(i: int) -> void:
	var z: Array = ZONES[i]
	cam_target = z[1]
	cam_dist = z[2]
	cam_pitch = z[3]
	cam_yaw = z[4]
	_update_camera()
	_status("Zone : " + str(z[0]))


# ---------------------------------------------------------------- interface
func _build_ui() -> void:
	layer = CanvasLayer.new()
	add_child(layer)
	panel = PanelContainer.new()
	panel.position = Vector2(8, 8)
	layer.add_child(panel)
	var vb := VBoxContainer.new()
	panel.add_child(vb)
	var title := Label.new()
	title.text = "Low Poly World Builder  -  %d pieces, %d packs" % [cat.size(), packs.size()]
	vb.add_child(title)
	search_edit = LineEdit.new()
	search_edit.placeholder_text = "Rechercher (ex. cactus, road, sofa)..."
	search_edit.clear_button_enabled = true
	search_edit.text_changed.connect(func(_t: String) -> void: _refresh_list())
	vb.add_child(search_edit)
	var hb := HBoxContainer.new()
	vb.add_child(hb)
	pack_opt = OptionButton.new()
	pack_opt.add_item("Tous les packs")
	for p in packs:
		pack_opt.add_item(PACK_NOMS.get(p, p))
	pack_opt.item_selected.connect(_on_pack)
	hb.add_child(pack_opt)
	cat_opt = OptionButton.new()
	cat_opt.item_selected.connect(func(_i: int) -> void: _refresh_list())
	hb.add_child(cat_opt)
	item_list = ItemList.new()
	item_list.custom_minimum_size = Vector2(330, 300)
	item_list.item_selected.connect(func(i: int) -> void: select_piece(str(item_list.get_item_metadata(i))))
	vb.add_child(item_list)
	info_label = Label.new()
	info_label.text = "Choisis une piece (T = tuile 4 m, H = hexagonale, D = dalle 2 m)."
	vb.add_child(info_label)
	var b1 := HBoxContainer.new()
	vb.add_child(b1)
	_button(b1, "Annuler", undo)
	_button(b1, "Refaire", redo)
	_button(b1, "Sauver", func() -> void: save_world(SAVE))
	_button(b1, "Charger", func() -> void: load_world(SAVE))
	var b2 := HBoxContainer.new()
	vb.add_child(b2)
	_button(b2, "Demo", func() -> void: load_world(DEMO))
	_button(b2, "Photo", func() -> void: photo())
	_button(b2, "Mode leger", func() -> void: set_light_mode(not light_mode))
	_button(b2, "Aide", func() -> void: help_label.visible = not help_label.visible)
	zone_opt = OptionButton.new()
	zone_opt.add_item("Aller a une zone...")
	for z in ZONES:
		zone_opt.add_item(str(z[0]))
	zone_opt.item_selected.connect(_on_zone)
	vb.add_child(zone_opt)
	help_label = Label.new()
	help_label.text = ("Clic gauche : poser (glisser = peindre des tuiles)   Clic droit / Suppr : supprimer\n"
		+ "R / Maj+R : tourner   G : grille 0,5 m pour les objets   Echap : lacher la piece\n"
		+ "Ctrl+Z : annuler   Ctrl+Y : refaire   Ctrl+S : sauver   Ctrl+L : charger\n"
		+ "ZQSD / WASD / fleches : deplacer   A/E (Q/E) : tourner la vue   Molette : zoom\n"
		+ "Clic molette : orbite   Maj + clic molette : glisser la vue\n"
		+ "1-5 : ambiance   F1-F%d : zones   P : photo 1920x1080   L : mode leger   Tab : panneau" % ZONES.size())
	help_label.visible = false
	vb.add_child(help_label)
	status_label = Label.new()
	vb.add_child(status_label)
	load_label = Label.new()
	load_label.position = Vector2(360, 12)
	layer.add_child(load_label)
	_on_pack(0)


func _on_zone(i: int) -> void:
	if i > 0:
		go_zone(i - 1)
	zone_opt.select(0)


func _button(parent: Control, text: String, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.pressed.connect(cb)
	parent.add_child(b)


func _on_pack(i: int) -> void:
	cur_cats = []
	for e in cat:
		if (i == 0 or e["pack"] == packs[i - 1]) and not cur_cats.has(e["cat"]):
			cur_cats.append(e["cat"])
	cur_cats.sort()
	cat_opt.clear()
	cat_opt.add_item("Toutes les categories")
	for c in cur_cats:
		cat_opt.add_item(c)
	_refresh_list()


func search(text: String, pack: String = "", categorie: String = "", limit: int = 500) -> Array:
	var r: Array = []
	var t := text.strip_edges().to_lower()
	for e in cat:
		if pack != "" and e["pack"] != pack:
			continue
		if categorie != "" and e["cat"] != categorie:
			continue
		if t != "" and not str(e["id"]).to_lower().contains(t) and not str(e["cat"]).to_lower().contains(t):
			continue
		r.append(e["id"])
		if r.size() >= limit:
			break
	return r


func _refresh_list() -> void:
	var pk := "" if pack_opt.selected <= 0 else str(packs[pack_opt.selected - 1])
	var ct := "" if cat_opt.selected <= 0 else str(cur_cats[cat_opt.selected - 1])
	item_list.clear()
	for ident in search(search_edit.text, pk, ct):
		var k: String = by_id[ident]["kind"]
		var tag: String = {"tuile": "[T] ", "hex": "[H] ", "dalle": "[D] ", "libre": ""}[k]
		var idx := item_list.add_item(tag + str(ident))
		item_list.set_item_metadata(idx, ident)


func _status(t: String = "") -> void:
	if status_label == null:
		return
	var s := "Ambiance : %s | %d pieces | %d modeles charges" % [AMB_NOMS[ambiance], placed.size(), scenes.size()]
	if snap_half:
		s += " | grille 0,5 m"
	if light_mode:
		s += " | MODE LEGER"
	status_label.text = s + ("\n" + t if t != "" else "")


# ---------------------------------------------------------------- pieces : chargement paresseux, pose
func model_path(ident: String) -> String:
	return "res://models/%s/%s.glb" % [by_id[ident]["pack"], ident]


func _scene(ident: String) -> PackedScene:
	if not scenes.has(ident):
		scenes[ident] = load(model_path(ident))
	return scenes[ident]


func _xform_from(t: Array) -> Transform3D:
	# base ecrite en lignes (comme les .tscn) -> colonnes Godot
	var b := Basis(Vector3(t[0], t[3], t[6]), Vector3(t[1], t[4], t[7]), Vector3(t[2], t[5], t[8]))
	return Transform3D(b, Vector3(t[9], t[10], t[11]))


func _xform_to(x: Transform3D) -> Array:
	var b := x.basis
	var r: Array = []
	for v in [b.x.x, b.y.x, b.z.x, b.x.y, b.y.y, b.z.y, b.x.z, b.y.z, b.z.z, x.origin.x, x.origin.y, x.origin.z]:
		r.append(snappedf(v, 0.0001))
	return r


func _vis_range(e: Dictionary) -> float:
	if e["kind"] != "libre":
		return 0.0
	var mn: Array = e["min"]
	var mx: Array = e["max"]
	var d := maxf(maxf(mx[0] - mn[0], mx[1] - mn[1]), mx[2] - mn[2])
	var r := 0.0
	if d < 0.8:
		r = 70.0
	elif d < 2.5:
		r = 150.0
	elif d < 6.0:
		r = 280.0
	return r * (0.6 if light_mode else 1.0)


func _setup_instance(n: Node3D, ident: String, mapping: Dictionary, mv: String = "") -> void:
	var e: Dictionary = by_id[ident]
	var m := _mat_for(e["pack"], mv)
	var vr := _vis_range(e)
	var mn: Array = e["min"]
	var mx: Array = e["max"]
	var small := maxf(maxf(mx[0] - mn[0], mx[1] - mn[1]), mx[2] - mn[2]) < 0.6
	for mi in n.find_children("*", "MeshInstance3D", true, false):
		var g := mi as MeshInstance3D
		if not mapping.is_empty():
			_recolor_mesh(g, mapping)
		g.material_override = m
		g.visibility_range_end = vr
		if small:
			g.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


func _recolor_mesh(mi: MeshInstance3D, mapping: Dictionary) -> void:
	# remappage de cases de palette (16 colonnes, UV au centre de la case) : meme teinte pour batiment + facades
	var src: Mesh = mi.mesh
	var key := "%d|%s" % [src.get_instance_id(), str(mapping)]
	if not mesh_cache.has(key):
		var nm := ArrayMesh.new()
		for sidx in src.get_surface_count():
			var arrays := src.surface_get_arrays(sidx)
			var uv: PackedVector2Array = arrays[Mesh.ARRAY_TEX_UV]
			for i in uv.size():
				var c := int(floor(uv[i].y * 16.0)) * 16 + int(floor(uv[i].x * 16.0))
				if mapping.has(c):
					var t: int = mapping[c]
					uv[i] = Vector2((float(t % 16) + 0.5) / 16.0, (floor(t / 16.0) + 0.5) / 16.0)
			arrays[Mesh.ARRAY_TEX_UV] = uv
			nm.add_surface_from_arrays(src.surface_get_primitive_type(sidx), arrays)
		mesh_cache[key] = nm
	mi.mesh = mesh_cache[key]


func _tile_key(ident: String, origin: Vector3) -> String:
	var k: String = by_id[ident]["kind"]
	match k:
		"tuile":
			return "T%d,%d" % [roundi(origin.x * 4.0), roundi(origin.z * 4.0)]
		"hex":
			var c := hex_cell(origin)
			return "H%d,%d" % [c.x, c.y]
		"dalle":
			return "D%d,%d,%d" % [roundi(origin.x * 4.0), roundi(origin.z * 4.0), roundi(origin.y * 2.0)]
	return ""


func _spawn_rec(rec: Dictionary) -> Node3D:
	var ident: String = rec["id"]
	if not by_id.has(ident):
		if not missing.has(ident):
			missing.append(ident)
		return null
	var n := _scene(ident).instantiate() as Node3D
	n.transform = rec["xf"]
	_setup_instance(n, ident, rec.get("c", {}), str(rec.get("m", "")))
	n.set_meta("rec", rec)
	pieces_root.add_child(n)
	placed.append(n)
	rec["node"] = n
	var tk := _tile_key(ident, n.position)
	if tk != "" and by_id[ident]["n"][0] <= 1:
		tile_at[tk] = n
	return n


func _despawn(rec: Dictionary) -> void:
	var n: Node3D = rec.get("node")
	if n == null or not is_instance_valid(n):
		return
	var tk := _tile_key(rec["id"], n.position)
	if tk != "" and tile_at.get(tk) == n:
		tile_at.erase(tk)
	placed.erase(n)
	n.queue_free()
	rec["node"] = null


func _new_rec(ident: String, xf: Transform3D, mapping: Dictionary = {}) -> Dictionary:
	return {"id": ident, "xf": xf, "c": mapping, "node": null}


# ---------------------------------------------------------------- annuler / refaire
func _do(action: Dictionary, push: bool = true) -> void:
	for rec in action["del"]:
		_despawn(rec)
	for rec in action["add"]:
		_spawn_rec(rec)
	if push:
		undo_stack.append(action)
		if undo_stack.size() > 200:
			undo_stack.pop_front()
		redo_stack.clear()
	_status()


func undo() -> bool:
	if undo_stack.is_empty():
		_status("Rien a annuler")
		return false
	var a: Dictionary = undo_stack.pop_back()
	for rec in a["add"]:
		_despawn(rec)
	for rec in a["del"]:
		_spawn_rec(rec)
	redo_stack.append(a)
	_status("Annule")
	return true


func redo() -> bool:
	if redo_stack.is_empty():
		_status("Rien a refaire")
		return false
	var a: Dictionary = redo_stack.pop_back()
	_do(a, false)
	undo_stack.append(a)
	_status("Refait")
	return true


# ---------------------------------------------------------------- aimants
func hex_center(c: Vector2i) -> Vector3:
	return Vector3(3.0 * c.x, 0.0, -2.0 * HA * (c.y + c.x / 2.0))


func hex_cell(p: Vector3) -> Vector2i:
	var qf := p.x / 3.0
	var rf := -p.z / (2.0 * HA) - qf / 2.0
	var sf := -qf - rf
	var q := roundf(qf)
	var r := roundf(rf)
	var s := roundf(sf)
	var dq := absf(q - qf)
	var dr := absf(r - rf)
	var ds := absf(s - sf)
	if dq > dr and dq > ds:
		q = -r - s
	elif dr > ds:
		r = -q - s
	return Vector2i(int(q), int(r))


func _local_center(e: Dictionary, r_deg: float) -> Vector3:
	var mn: Array = e["min"]
	var mx: Array = e["max"]
	var c := Vector3((mn[0] + mx[0]) * 0.5, 0.0, (mn[2] + mx[2]) * 0.5)
	return Basis(Vector3.UP, deg_to_rad(r_deg)) * c


func snap_for(e: Dictionary, p: Vector3, r_deg: float = 0.0) -> Vector3:
	match str(e["kind"]):
		"tuile":
			var n := int(e["n"][0])
			var off := 0.0 if n % 2 == 1 else 2.0
			var c := Vector3(roundf((p.x - off) / TILE) * TILE + off, 0.0, roundf((p.z - off) / TILE) * TILE + off)
			var lc := _local_center(e, r_deg)
			return Vector3(c.x - lc.x, 0.0, c.z - lc.z)
		"hex":
			return hex_center(hex_cell(p))
		"dalle":
			var c2 := Vector3(floorf(p.x / 2.0) * 2.0 + 1.0, 0.0, floorf(p.z / 2.0) * 2.0 + 1.0)
			var lc2 := _local_center(e, r_deg)
			return Vector3(c2.x - lc2.x, 0.0, c2.z - lc2.z)
	var q := Vector3(p.x, 0.0, p.z)
	if snap_half:
		q = Vector3(roundf(p.x * 2.0) / 2.0, 0.0, roundf(p.z * 2.0) / 2.0)
	q.y = _ground_top(q)
	return q


func _ground_top(p: Vector3) -> float:
	# les objets libres se posent sur la tuile qui est dessous (trottoir, dalle...)
	var tk := "T%d,%d" % [roundi(roundf(p.x / TILE) * TILE * 4.0), roundi(roundf(p.z / TILE) * TILE * 4.0)]
	var n: Node3D = tile_at.get(tk)
	if n != null and is_instance_valid(n):
		var e: Dictionary = by_id[n.get_meta("rec")["id"]]
		var top: float = e["max"][1]
		return n.position.y + clampf(top, 0.0, 0.2)
	return 0.0


# ---------------------------------------------------------------- outil de construction
func select_piece(ident: String) -> void:
	if not by_id.has(ident):
		return
	current = by_id[ident]
	rot = 0.0
	_drop_ghost()
	ghost = _scene(ident).instantiate() as Node3D
	for mi in ghost.find_children("*", "MeshInstance3D", true, false):
		(mi as MeshInstance3D).material_override = ghost_mats[current["pack"]]
		(mi as MeshInstance3D).cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ghost)
	var mn: Array = current["min"]
	var mx: Array = current["max"]
	var genre: String = {"tuile": "tuile 4 m (aimant)", "hex": "tuile hexagonale (aimant)", "dalle": "dalle 2 m (aimant)",
		"libre": "objet libre"}[current["kind"]]
	info_label.text = "%s\n%s - %s  %.2f x %.2f x %.2f m" % [ident, PACK_NOMS.get(current["pack"], ""), genre,
		mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]]
	_update_ghost()
	_status()


func _drop_ghost() -> void:
	if ghost:
		ghost.queue_free()
		ghost = null


func place_current(p: Vector3, action: Dictionary = {}) -> Node3D:
	if current.is_empty():
		return null
	var ident: String = current["id"]
	var pos := snap_for(current, p, rot)
	var xf := Transform3D(Basis(Vector3.UP, deg_to_rad(rot)), pos)
	var a := action if not action.is_empty() else {"add": [], "del": []}
	var tk := _tile_key(ident, pos)
	if tk != "":
		var old: Node3D = tile_at.get(tk)
		if old != null and is_instance_valid(old):
			var orec: Dictionary = old.get_meta("rec")
			if orec["id"] == ident and old.transform.is_equal_approx(xf):
				return null
			a["del"].append(orec)
			_despawn(orec)
	var rec := _new_rec(ident, xf)
	a["add"].append(rec)
	_spawn_rec(rec)
	if action.is_empty():
		undo_stack.append(a)
		redo_stack.clear()
	_status()
	return rec["node"]


func delete_near(p: Vector3, radius: float = 2.5) -> bool:
	var best: Node3D = null
	var bd := radius
	var best_tile: Node3D = null
	var bdt := radius
	for n in placed:
		var d := Vector2(n.position.x - p.x, n.position.z - p.z).length()
		var k: String = by_id[n.get_meta("rec")["id"]]["kind"]
		if k == "libre":
			if d < bd:
				bd = d
				best = n
		elif d < bdt:
			bdt = d
			best_tile = n
	if best == null:
		best = best_tile
	if best == null:
		return false
	var rec: Dictionary = best.get_meta("rec")
	_do({"add": [], "del": [rec]})
	_status("Supprime : " + str(rec["id"]))
	return true


func clear_all() -> void:
	for n in placed:
		n.queue_free()
	placed.clear()
	tile_at.clear()
	undo_stack.clear()
	redo_stack.clear()


# ---------------------------------------------------------------- sauvegarde / chargement
func world_dict() -> Dictionary:
	var arr: Array = []
	for n in placed:
		var rec: Dictionary = n.get_meta("rec")
		var d := {"id": rec["id"], "t": _xform_to(n.transform)}
		if not (rec.get("c", {}) as Dictionary).is_empty():
			d["c"] = rec["c"]
		if rec.has("g"):
			d["g"] = rec["g"]
		if str(rec.get("m", "")) != "":
			d["m"] = rec["m"]
		arr.append(d)
	return {"format": "amano_world_builder", "version": 1, "ambiance": ambiance, "pieces": arr}


func save_world(path: String) -> bool:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		_status("Sauvegarde impossible : " + path)
		return false
	f.store_string(JSON.stringify(world_dict()))
	f.close()
	_status("Sauve : %s (%d pieces)" % [ProjectSettings.globalize_path(path), placed.size()])
	return true


func load_world(path: String) -> bool:
	if loading or not FileAccess.file_exists(path):
		_status("Aucun fichier : " + path)
		return false
	loading = true
	var d: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(path))
	clear_all()
	var list: Array = d["pieces"]
	# 1) chargement en arriere-plan des SEULS modeles utilises par ce monde
	var need: Array = []
	for p in list:
		var ident: String = p["id"]
		if by_id.has(ident) and not scenes.has(ident) and not need.has(ident):
			need.append(ident)
	# (chargement sur le fil principal, par paquets : sur certains pilotes le chargement en threads cree des erreurs)
	var done := 0
	for ident in need:
		scenes[ident] = load(model_path(ident))
		done += 1
		if done % 25 == 0:
			load_label.text = "Chargement des modeles : %d / %d" % [done, need.size()]
			await get_tree().process_frame
	# 2) pose des pieces par paquets (la fenetre reste reactive)
	var k := 0
	for p in list:
		var rec := _new_rec(p["id"], _xform_from(p["t"]))
		if p.has("c"):
			var mp := {}
			for key in (p["c"] as Dictionary):
				mp[int(key)] = int(p["c"][key])
			rec["c"] = mp
		if p.has("g"):
			rec["g"] = p["g"]
		if p.has("m"):
			rec["m"] = p["m"]
		_spawn_rec(rec)
		k += 1
		if k % 700 == 0:
			load_label.text = "Pose des pieces : %d %%" % int(100.0 * k / list.size())
			await get_tree().process_frame
	load_label.text = ""
	set_ambiance(str(d.get("ambiance", "day")))
	loading = false
	_status("Charge : %s" % path)
	return true


# ---------------------------------------------------------------- ambiances, mode leger, photo
func set_ambiance(a: String) -> void:
	ambiance = a
	_apply_materials_for(a)
	var w := _desert_weights(cam_target) if a == "day" else Vector2.ZERO
	_apply_light(a, w.x, w.y)
	last_tint_target = cam_target
	_status()


func set_light_mode(on: bool) -> void:
	light_mode = on
	env.ssao_enabled = not on
	env.fog_enabled = not on
	env.glow_enabled = not on
	sun.shadow_enabled = not on
	if horizon != null:
		horizon.visible = not on
	if far_decor != null:
		far_decor.visible = not on
	get_viewport().scaling_3d_scale = 0.75 if on else 1.0
	for n in placed:
		var vr := _vis_range(by_id[n.get_meta("rec")["id"]])
		for mi in n.find_children("*", "MeshInstance3D", true, false):
			(mi as MeshInstance3D).visibility_range_end = vr
	_status("Mode leger : ombres, SSAO, brouillard et halo coupes" if on else "Rendu complet")


func photo(path: String = "") -> String:
	if path == "":
		DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://captures"))
		path = "user://captures/photo_%s.png" % Time.get_datetime_string_from_system().replace(":", "-")
	if DisplayServer.get_name() == "headless":
		return ""
	var sv := SubViewport.new()
	sv.size = Vector2i(1920, 1080)
	sv.world_3d = get_viewport().world_3d
	sv.msaa_3d = Viewport.MSAA_4X
	sv.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	var c := Camera3D.new()
	c.fov = cam.fov
	c.far = cam.far
	sv.add_child(c)
	add_child(sv)
	c.global_transform = cam.global_transform
	c.current = true
	if ghost:
		ghost.visible = false
	for i in 4:
		await RenderingServer.frame_post_draw
	var img := sv.get_texture().get_image()
	img.save_png(path)
	sv.queue_free()
	if ghost:
		ghost.visible = true
	var out := ProjectSettings.globalize_path(path)
	_status("Photo 1920x1080 : " + out)
	return out


# ---------------------------------------------------------------- entrees
func _ground_point() -> Variant:
	var mp := get_viewport().get_mouse_position()
	return Plane(Vector3.UP, 0.0).intersects_ray(cam.project_ray_origin(mp), cam.project_ray_normal(mp))


func _update_ghost() -> void:
	if ghost == null or current.is_empty():
		return
	var g: Variant = _ground_point()
	if g == null:
		return
	ghost.position = snap_for(current, g, rot)
	ghost.rotation.y = deg_to_rad(rot)


func _rot_step() -> float:
	return {"tuile": 90.0, "dalle": 90.0, "hex": 60.0, "libre": 15.0}[current.get("kind", "libre")]


func _unhandled_input(event: InputEvent) -> void:
	if loading:
		return
	if event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if orbit_drag:
			cam_yaw -= mm.relative.x * 0.3
			cam_pitch = clampf(cam_pitch - mm.relative.y * 0.3, -88.0, -8.0)
			_update_camera()
		elif pan_drag:
			var right := cam.global_transform.basis.x
			var fwd := Vector3(-right.z, 0, right.x)
			cam_target -= (right * mm.relative.x - fwd * mm.relative.y) * cam_dist * 0.0016
			_update_camera()
		_update_ghost()
		if not drag_action.is_empty() and current.get("kind", "libre") != "libre":
			var g0: Variant = _ground_point()
			if g0 != null:
				place_current(g0, drag_action)
	elif event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		var g: Variant = _ground_point()
		if mb.button_index == MOUSE_BUTTON_MIDDLE:
			orbit_drag = mb.pressed and not mb.shift_pressed
			pan_drag = mb.pressed and mb.shift_pressed
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			cam_dist = clampf(cam_dist * 0.9, 4.0, 420.0)
			_update_camera()
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			cam_dist = clampf(cam_dist * 1.1, 4.0, 420.0)
			_update_camera()
		elif mb.button_index == MOUSE_BUTTON_LEFT:
			if mb.pressed and g != null and not current.is_empty():
				drag_action = {"add": [], "del": []}
				place_current(g, drag_action)
			elif not mb.pressed and not drag_action.is_empty():
				if not (drag_action["add"] as Array).is_empty():
					undo_stack.append(drag_action)
					redo_stack.clear()
				drag_action = {}
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_RIGHT and g != null:
			delete_near(g)
	elif event is InputEventKey and event.pressed and not event.echo:
		var k := event as InputEventKey
		if k.ctrl_pressed:
			# keycode = lettre imprimee sur la touche (AZERTY et QWERTY)
			match k.keycode:
				KEY_Z:
					if k.shift_pressed:
						redo()
					else:
						undo()
				KEY_Y:
					redo()
				KEY_S:
					save_world(SAVE)
				KEY_L:
					load_world(SAVE)
			return
		match k.keycode:
			KEY_R:
				rot = fposmod(rot + (-_rot_step() if k.shift_pressed else _rot_step()), 360.0)
				_update_ghost()
			KEY_G:
				snap_half = not snap_half
				_status()
			KEY_DELETE, KEY_X:
				var g2: Variant = _ground_point()
				if g2 != null:
					delete_near(g2)
			KEY_ESCAPE:
				current = {}
				_drop_ghost()
				info_label.text = "Aucune piece choisie."
			KEY_TAB:
				panel.visible = not panel.visible
			KEY_P:
				photo()
			KEY_L:
				set_light_mode(not light_mode)
			KEY_H:
				help_label.visible = not help_label.visible
			KEY_1, KEY_2, KEY_3, KEY_4, KEY_5:
				set_ambiance(AMBIANCES[k.keycode - KEY_1])
			KEY_F1, KEY_F2, KEY_F3, KEY_F4, KEY_F5, KEY_F6, KEY_F7, KEY_F8:
				if k.keycode - KEY_F1 < ZONES.size():
					go_zone(k.keycode - KEY_F1)


func _process(delta: float) -> void:
	if search_edit != null and search_edit.has_focus():
		return
	var v := Vector3.ZERO
	if Input.is_physical_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		v.z -= 1
	if Input.is_physical_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		v.z += 1
	if Input.is_physical_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		v.x -= 1
	if Input.is_physical_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		v.x += 1
	var turn := 0.0
	if Input.is_physical_key_pressed(KEY_Q):
		turn += 1.0
	if Input.is_physical_key_pressed(KEY_E):
		turn -= 1.0
	if v != Vector3.ZERO or turn != 0.0:
		cam_yaw += turn * 70.0 * delta
		cam_target += Basis(Vector3.UP, deg_to_rad(cam_yaw)) * v.normalized() * cam_dist * 0.8 * delta
		_update_camera()
		_update_ghost()


# ---------------------------------------------------------------- captures (visuels)
func _run_shots() -> void:
	var out := OS.get_environment("SHOTS_DIR")
	panel.visible = false
	await get_tree().create_timer(1.0).timeout
	var vues := [
		["1_vue_ensemble", Vector3(22, 0, 24), 112.0, -33.0, 32.0, "day", 52.0],
		["2_ville_vue_basse", Vector3(-10, 4, 0), 40.0, -14.0, 90.0, "day", 58.0],
		["3_autoroute_route66", Vector3(78, 2, 0), 54.0, -21.0, 64.0, "day", 58.0],
		["4_autoroute_bazar", Vector3(0, 2, 84), 62.0, -15.0, 205.0, "day", 58.0],
		["5_ile_hex", Vector3(-132, 0, 2), 48.0, -26.0, 205.0, "day", 55.0],
		["6_halloween", Vector3(0, 1, -90), 42.0, -40.0, 15.0, "day", 58.0],
		["7_showroom", Vector3(-52, 1, -52), 30.0, -40.0, -90.0, "day", 58.0],
		["8_ville_nuit", Vector3(-10, 4, 0), 40.0, -14.0, 90.0, "night", 58.0],
	]
	var t0 := Time.get_ticks_msec()
	var frames := 0
	for v in vues:
		set_ambiance(v[5])
		cam_target = v[1]
		cam_dist = v[2]
		cam_pitch = v[3]
		cam_yaw = v[4]
		cam.fov = v[6]
		last_tint_target = Vector3(1e9, 0, 0)
		_update_camera()
		for i in 30:
			await get_tree().process_frame
			frames += 1
		print("%s : %d FPS, %d objets dessines, %d appels de dessin" % [v[0], Engine.get_frames_per_second(),
			RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_OBJECTS_IN_FRAME),
			RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TOTAL_DRAW_CALLS_IN_FRAME)])
		await photo(out + "/" + str(v[0]) + ".png")
	# cout de l'horizon (montagnes lointaines) : meme cadrage que la vue 1, avec puis sans
	set_ambiance("day")
	cam_target = vues[0][1]
	cam_dist = vues[0][2]
	cam_pitch = vues[0][3]
	cam_yaw = vues[0][4]
	cam.fov = vues[0][6]
	_update_camera()
	for hv in [true, false, true]:
		horizon.visible = hv
		far_decor.visible = hv
		for i in 90:
			await get_tree().process_frame
		print("vue 1, montagnes + decor lointain %s : %d FPS" % ["visibles" if hv else "caches", Engine.get_frames_per_second()])
	set_light_mode(true)
	go_zone(0)
	for i in 60:
		await get_tree().process_frame
	print("mode leger, vue ville : %d FPS" % Engine.get_frames_per_second())
	print("captures : %d images en %.1f s, memoire video %.0f Mo" % [frames, (Time.get_ticks_msec() - t0) / 1000.0,
		RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_VIDEO_MEM_USED) / 1048576.0])
	get_tree().quit()


# ---------------------------------------------------------------- test sans fenetre
func _run_tests() -> void:
	var fails: Array = []
	var expected := {"town": 281, "terrain": 163, "hex": 174, "interiors": 398, "garage": 92, "laverie": 93,
		"halloween": 231, "route66": 174, "bazar": 250}
	var total_exp := 1856
	var tier := str(palier.get("tier", "pro"))
	if palier.has("expected"):
		expected = palier["expected"]
		total_exp = int(palier["total"])
	var count := {}
	for e in cat:
		count[e["pack"]] = count.get(e["pack"], 0) + 1
		if not ResourceLoader.exists(model_path(e["id"])):
			fails.append("modele absent : " + str(e["id"]))
	for p in expected:
		if count.get(p, 0) != expected[p]:
			fails.append("pack %s : %d pieces au lieu de %d" % [p, count.get(p, 0), expected[p]])
	if cat.size() != total_exp:
		fails.append("catalogue : %d pieces au lieu de %d" % [cat.size(), total_exp])
	if palier.has("demo_pieces") and placed.size() != int(palier["demo_pieces"]):
		fails.append("monde de demo : %d pieces au lieu de %d" % [placed.size(), int(palier["demo_pieces"])])
	var demo: Dictionary = JSON.parse_string(FileAccess.get_file_as_string(DEMO))
	var n_demo: int = (demo["pieces"] as Array).size()
	if placed.size() != n_demo or not missing.is_empty():
		fails.append("monde demo : %d / %d poses, absents %s" % [placed.size(), n_demo, str(missing)])
	# chargement paresseux : seuls les modeles du monde sont en memoire
	var loaded0 := scenes.size()
	if loaded0 > cat.size() or loaded0 > 900 or (tier == "pro" and loaded0 >= cat.size()):
		fails.append("chargement paresseux : %d modeles en memoire" % loaded0)
	var unused := ""
	for e in cat:
		if not scenes.has(e["id"]):
			unused = e["id"]
			break
	if unused != "":
		select_piece(unused)
	if unused != "" and scenes.size() != loaded0 + 1:
		fails.append("chargement a la demande de " + unused)
	# aimants
	var s := snap_for(by_id["Town_Road_Straight"], Vector3(5.1, 0, -1.9))
	if s.distance_to(Vector3(4, 0, 0)) > 0.01:
		fails.append("aimant tuile : %s" % str(s))
	var hc := hex_center(hex_cell(Vector3(3.4, 0, 2.0)))
	if hex_center(hex_cell(hc)).distance_to(hc) > 0.001 or hc.distance_to(Vector3(3.4, 0, 2.0)) > 2.1:
		fails.append("aimant hex : %s" % str(hc))
	var d2 := snap_for(by_id["Interiors_Floor_Wood"], Vector3(0.4, 0, 0.3))
	var lc := _local_center(by_id["Interiors_Floor_Wood"], 0.0)
	if Vector3(d2.x + lc.x, 0, d2.z + lc.z).distance_to(Vector3(1, 0, 1)) > 0.01:
		fails.append("aimant dalle : %s" % str(d2))
	# pose, remplacement, annuler / refaire
	var n0 := placed.size()
	select_piece("Town_Road_Straight")
	place_current(Vector3(400.3, 0, 400.2))
	if placed.size() != n0 + 1:
		fails.append("pose tuile")
	select_piece("Town_Road_Cross")
	place_current(Vector3(401.0, 0, 399.0))
	var at: Node3D = tile_at.get(_tile_key("Town_Road_Cross", Vector3(400, 0, 400)))
	if placed.size() != n0 + 1 or at == null or at.get_meta("rec")["id"] != "Town_Road_Cross":
		fails.append("remplacement de tuile")
	undo()
	at = tile_at.get(_tile_key("Town_Road_Straight", Vector3(400, 0, 400)))
	if at == null or at.get_meta("rec")["id"] != "Town_Road_Straight" or placed.size() != n0 + 1:
		fails.append("annuler remplacement")
	undo()
	if placed.size() != n0:
		fails.append("annuler pose")
	redo()
	redo()
	at = tile_at.get(_tile_key("Town_Road_Straight", Vector3(400, 0, 400)))
	if placed.size() != n0 + 1 or at == null or at.get_meta("rec")["id"] != "Town_Road_Cross":
		fails.append("refaire")
	var free_id := "Route66_Joshua_Tree" if by_id.has("Route66_Joshua_Tree") else ""
	if free_id == "":
		for e in cat:
			if e["kind"] == "libre":
				free_id = e["id"]
				break
	select_piece(free_id)
	rot = 45.0
	var obj := place_current(Vector3(410.2, 0, 400.0))
	if obj == null or absf(obj.rotation_degrees.y - 45.0) > 0.1:
		fails.append("objet libre + rotation")
	delete_near(Vector3(410.0, 0, 400.0))
	if placed.size() != n0 + 1:
		fails.append("suppression")
	undo()
	if placed.size() != n0 + 2:
		fails.append("annuler suppression")
	redo()
	if placed.size() != n0 + 1:
		fails.append("refaire suppression")
	# peinture de tuiles en glissant = une seule action
	var paint_id := "Terrain_Ground_Sand" if by_id.has("Terrain_Ground_Sand") else "Town_Road_Straight"
	select_piece(paint_id)
	var da := {"add": [], "del": []}
	for i in 5:
		place_current(Vector3(420.0 + i * 4.0, 0, 420.0), da)
	undo_stack.append(da)
	if placed.size() != n0 + 6:
		fails.append("peinture de tuiles")
	undo()
	if placed.size() != n0 + 1:
		fails.append("annuler peinture")
	# recherche
	var n_cactus := 0
	var n_sofa := 0
	for e in cat:
		if str(e["id"]).to_lower().contains("cactus"):
			n_cactus += 1
		if e["pack"] == "interiors" and str(e["id"]).to_lower().contains("sofa"):
			n_sofa += 1
	var r1 := search("cactus")
	if r1.size() != n_cactus or (tier == "pro" and n_cactus < 8):
		fails.append("recherche cactus : %d / %d" % [r1.size(), n_cactus])
	for ident in r1:
		if not str(ident).to_lower().contains("cactus"):
			fails.append("recherche : " + str(ident))
	if search("sofa", "interiors").size() != n_sofa or search("zzzz").size() != 0:
		fails.append("recherche filtree")
	# ambiances
	for a in AMBIANCES:
		set_ambiance(a)
		for p in packs:
			var m: StandardMaterial3D = mats[p]
			if m.albedo_texture == null or not m.albedo_texture.resource_path.ends_with("%s/palette_%s.png" % [p, a]):
				fails.append("palette %s / %s" % [p, a])
			if m.emission_texture == null:
				fails.append("emission %s / %s" % [p, a])
	set_ambiance("night")
	if (mats["town"] as StandardMaterial3D).emission_energy_multiplier <= 1.5 or sun.light_energy > 1.0:
		fails.append("ambiance nuit")
	var mi0 := (placed[0] as Node3D).find_children("*", "MeshInstance3D", true, false)[0] as MeshInstance3D
	if mi0.material_override != mats[by_id[placed[0].get_meta("rec")["id"]]["pack"]]:
		fails.append("materiau partage")
	# mode leger
	set_light_mode(true)
	if env.ssao_enabled or sun.shadow_enabled or env.fog_enabled or horizon.visible or far_decor.visible:
		fails.append("mode leger")
	if far_decor.mesh == null or far_decor.mesh.get_surface_count() == 0:
		fails.append("decor lointain vide")
	set_light_mode(false)
	if not env.ssao_enabled or not sun.shadow_enabled:
		fails.append("retour rendu complet")
	# couleurs des batiments (remappage) conservees par sauvegarde / chargement
	var n_rec := 0
	var n_mv := 0
	for n in placed:
		if not (n.get_meta("rec").get("c", {}) as Dictionary).is_empty():
			n_rec += 1
		if str(n.get_meta("rec").get("m", "")) != "":
			n_mv += 1
	go_zone(mini(2, ZONES.size() - 1))
	var cnt := placed.size()
	save_world("user://test_monde.json")
	clear_all()
	if placed.size() != 0:
		fails.append("effacement")
	await load_world("user://test_monde.json")
	var n_rec2 := 0
	var n_mv2 := 0
	var mv_ok := true
	for n in placed:
		if not (n.get_meta("rec").get("c", {}) as Dictionary).is_empty():
			n_rec2 += 1
		var mvn := str(n.get_meta("rec").get("m", ""))
		if mvn != "":
			n_mv2 += 1
			var mi1 := n.find_children("*", "MeshInstance3D", true, false)[0] as MeshInstance3D
			if mi1.material_override != mats[str(by_id[n.get_meta("rec")["id"]]["pack"]) + "|" + mvn]:
				mv_ok = false
	if (n_mv == 0 and tier != "standard") or n_mv2 != n_mv or not mv_ok:
		fails.append("variantes de saison (herbe seche) : %d / %d" % [n_mv2, n_mv])
	if placed.size() != cnt or ambiance != "night" or n_rec2 != n_rec or n_rec == 0:
		fails.append("sauvegarde/chargement : %d / %d, %s, couleurs %d / %d" % [placed.size(), cnt, ambiance, n_rec2, n_rec])
	# export des autoroutes telles que posees (verifiees ensuite par tools/verif_raccords.py)
	var hw: Array = []
	for n in placed:
		var rec: Dictionary = n.get_meta("rec")
		if str(rec.get("g", "")).begins_with("hw_"):
			hw.append({"id": rec["id"], "t": _xform_to(n.transform), "g": rec["g"]})
	var f := FileAccess.open("user://test_autoroutes.json", FileAccess.WRITE)
	f.store_string(JSON.stringify({"pieces": hw}))
	f.close()
	if hw.size() < int(palier.get("hw_min", 70)):
		fails.append("autoroutes : %d pieces" % hw.size())
	for i in ZONES.size():
		go_zone(i)
	if fails.is_empty():
		print("TEST OK : palier %s, catalogue %d (%d packs), monde %d pieces charge en %.1f s, %d modeles en memoire (paresseux), "
			% [tier, cat.size(), packs.size(), n_demo, load_ms / 1000.0, loaded0]
			+ "aimants tuile/hex/dalle, pose/remplacement/suppression, annuler/refaire, recherche, 5 ambiances, "
			+ "mode leger, sauvegarde/chargement (%d batiments recolores), %d zones" % [n_rec, ZONES.size()])
		print("AUTOROUTES_EXPORT=" + ProjectSettings.globalize_path("user://test_autoroutes.json"))
		get_tree().quit(0)
	else:
		print("TEST ECHEC : ", fails)
		get_tree().quit(1)
