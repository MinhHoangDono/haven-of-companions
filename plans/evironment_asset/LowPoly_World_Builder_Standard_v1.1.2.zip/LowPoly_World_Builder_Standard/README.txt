LOW POLY WORLD BUILDER STANDARD v1.1.2  -  par Amano007
================================================================================

A scene for Godot 4.7 : a simple building tool to make your own low poly world with the pieces of the
Amano007 modern-world packs, plus a demo world.
TIERS (one page, 3 files) : Standard Free (pay what you want, from $0) / Complete $4.50 / Pro $8.50.
(Une version francaise courte est en bas du fichier.)

WHAT IS INSIDE (Standard tier)
- 270 pieces from the 9 packs, 30 per pack (Town Starter 30, Terrain 30, Terrain Hex 30, Interiors 30, Garage 30, Laundromat 30, Halloween 30, Route 66 Desert Stop 30, Bazar 30). Only pieces that are already FREE in the Standard (free) file of their own pack : nothing paid is in this tier. Full list : LISTE_PIECES.txt.
- A small demo world : a village corner with a ring road, a cafe, a house, a brick shop with 2 floors, a gas station, a park, a river with a wooden bridge and a small farm (440 placed pieces, 54 different models, all of them from the free pieces of this tier).
- The whole building tool (same as the paid tiers) : snapping tiles (4 m square grid, hexagon grid, 2 m floor grid), free objects, rotate, delete, undo / redo, search, 5 moods, save / load, photo mode, light mode.
- Not in this tier : the other pieces of the 9 packs and the big demo world (city, countryside, highways, Route 66, Bazar, hex island, Halloween, showroom). They are in the Complete tier ($4.50, 827 pieces + the big world) and in the Pro tier ($8.50, all 1 856 pieces).

INSTALL
1. Install Godot 4.7 (free) : https://godotengine.org
2. Unzip this folder, open Godot, "Import", choose project.godot.
3. The first opening imports the 270 models : less than 1 minute on a modest PC (Godot 4.7.2 headless, once only ; it can be slower on other computers).
4. Press F5 (Run).
Size : 11.4 MB unzipped (+ the Godot import cache created on first opening).
Models are loaded only when needed (never all of them at once).

CONTROLS
- Left click : place the chosen piece (hold and drag to paint tiles)
- Right click / Delete / X : delete the nearest piece (objects first, then tiles)
- R / Shift+R : rotate (90 deg tiles, 60 deg hexagons, 15 deg objects)
- G : 0.5 m grid for free objects        Esc : drop the piece
- Ctrl+Z : undo        Ctrl+Y (or Ctrl+Shift+Z) : redo
- Ctrl+S : save (user://mon_monde.json)  Ctrl+L : load        "Demo" button : demo world again
- W A S D / Z Q S D / arrows : move the view     Q / E (A / E on AZERTY) : turn the view
- Mouse wheel : zoom     Middle mouse drag : orbit     Shift + middle drag : pan
- 1 Day  2 Night  3 Pastel  4 Winter  5 Sunset
- F1 : go to the demo village (the zone list of the panel has one entry)
- P : photo 1920 x 1080 (saved in user://captures ; the path is shown in the panel)
- L : light mode (no shadows, no ambient occlusion, no fog, no glow, 75 % render scale)
- Tab : hide the panel     H : help
The search box finds pieces by name or category in all packs (ex. "cactus", "road", "sofa").
[T] = 4 m tile, [H] = hexagon tile, [D] = 2 m floor tile, no mark = free object.

GOOD TO KNOW (honest notes)
- Each pack keeps its own palette texture : the scene uses one shared material per pack.
  Moods use the hand-made palettes of each pack when they exist ; the others are generated
  approximations (see data/palette_map.json). The night mood mixes the day palette with the
  pack night palette so that it is not too blue.
- The models in models/ are imported WITHOUT their embedded texture (the scene applies the pack
  palette). To use a model in your own project with its texture, take the GLB/FBX/OBJ of the pack.
- RENDER HELPERS (not models of the packs, made by the scene script) : the sky, the coloured ground under the world, the ring of far mountains and the simple far hills and rocks. They are hidden in light mode (L), except the sky and the ground.
- Speed depends on your computer. Use light mode (L) if it is slow. Not tested in Unity or Unreal (this scene is Godot only ; the models of the packs work in any engine).

LICENSE : see LICENSE.txt (use in your projects, resale or redistribution forbidden).

--------------------------------------------------------------------------------
EN FRANCAIS (resume)
Palier Standard : 270 pieces. Prix de la page : Standard gratuit / Complete 4,50 $ / Pro 8,50 $.
Ouvrir project.godot avec Godot 4.7 (premier import : moins d'une minute), puis F5.
Clic gauche poser, clic droit supprimer, R tourner, Ctrl+Z / Ctrl+Y annuler / refaire,
Ctrl+S / Ctrl+L sauver / charger, 1-5 ambiances, F1 zones, P photo, L mode leger, Tab panneau.
Le palier Standard ne contient que des pieces deja gratuites dans les packs. La recherche trouve une piece par son nom. Revente des modeles interdite.

CHANGELOG
  1.1.2  Standard tier now contains ONLY pieces that are already free in the Standard files of the 9 packs (30 per pack, 270 in total ; 199 pieces replaced, 71 kept). New small demo village made only with these free pieces. Paid tiers : Complete $4.50, Pro $8.50.
  1.1.1  Three tiers on one page (Standard free / Complete / Pro). Standard : 270 pieces, whole tool, small demo village. Same tool as 1.0.0 ; the piece list shown in the tool depends on the tier.
  1.0.0  First version (single file, 1,856 pieces).
