Low Poly Terrain Kit v1.0.3 - Standard edition
=============================================

FREE (name your own price, from $0): 30 hand-picked pieces (spring colors), GLB / FBX / OBJ - enough to build a small map with ground, slopes, cliffs, a river, a path, a road, a bridge and trees.

Modular low poly landscape for strategy, city-builder, RPG, survival and adventure prototypes - and for renders.
Square tiles of 4 x 4 m snap together: ground, hills, slopes, cliffs (2 m and 4 m), lakes, rivers, waterfalls, paths,
roads, bridges - plus trees, rocks, plants and props. Four seasons from one shared palette.
Part of the "Amano Props" series: same style, same scale and the same 2 m grid in every pack (a tile = 2 x 2 grid cells).

CONTENTS
  Models/GLB/        glTF binary, spring colors (recommended: Godot 4, Unity with glTFast, Unreal 5, Three.js)
  Models/FBX/        FBX (Unity, Unreal, Blender) - the palette texture sits next to the models and loads automatically
  Models/OBJ/        OBJ + MTL
  Textures/          props_palette.png (128x256 color palette) + props_emission.png (glow map)
  Docs/              STYLE_GUIDE.txt, Palette_Chart.png, tiles.json (tile sockets), Kit_Guide.txt

CHANGELOG
  1.0.3  Kit guide updated: the Pro edition now ships eight example maps
  1.0.2  OBJ + FBX: textures load automatically (palette next to the FBX files, .mtl paths to Textures/)
  1.0.1  OBJ: .mtl texture paths now point to Textures/ (the palette loads automatically in Blender / Godot)
  1.0.0  initial release: 163 pieces in Complete / Pro (tiles, trees, rocks, plants, props, bridges), 4 seasons

SPECS
  - Scale: 1 unit = 1 meter. Tiles are 4 x 4 m, origin at the tile centre, the walkable surface is at height 0.
    Plateau / raised pieces: surface at 2 m (Plateau_*, Cliff pieces step from 0 to 2) or 4 m (*_Tall).
    Every tile has a closed skirt down to -2 m (so a lone tile looks like a little diorama block).
  - Models are Z-up in Blender and exported Y-up (glTF / FBX / OBJ). Pieces are rotated in 90 degree steps.
  - Dimensions: road 3 m wide, river 2 m of water + 0.5 m banks, path 1 m, bridges 4 m long (across the river
    flowing north-south), cliff height 2 m (4 m for Cliff_Tall_*), slope 2 m rise over 4 m.
  - Tile edges are exactly identical between compatible tiles: see Docs/tiles.json ("sockets"). Any two edges with
    matching sockets join without a gap, whatever the piece (ground, river, road, cliff, slope, lake shore).
  - One shared material / one 128 x 256 palette texture for the whole pack. Use NEAREST (point) filtering.
    Alternative seasons: Textures/props_palette_autumn.png, _snow.png, _desert.png (same UVs: swap the image) and the
    ready-made Models/GLB_Autumn, GLB_Snow, GLB_Desert folders.
  - Flame colors (campfire, torch, lantern glass) use the emission map props_emission.png (optional).
  - Faces: 20 to 1,000 per object, about 380 per tile (a 12 x 10 map is under 60,000 faces).

TILE KIT CHEAT SHEET (orientation of the pieces when imported as they are)
  Slope_* / Cliff_* / River_Slope / Waterfall_* : high side to the NORTH (+Y in Blender, -Z in Godot).
  *_Corner_Out : only the NE corner is high.   *_Corner_In : only the SW corner is low.
  River_/Path_/Road_ Straight: north-south.   Bend: south to east.   Tee: west, east and south.   End/Source: south.
  Water_Shore_Edge: water to the south.   Water_Shore_Corner_Out: water in the SW corner only.
  Bridges span west-east (put them on a north-south river).
  See Docs/Kit_Guide.txt for how to build ramps, plateaus and waterfalls.

ASSETS (30)
  [Ground] Ground_Grass_A  (385 faces)
  [Ground] Ground_Grass_B  (385 faces)
  [Ground] Ground_Dirt  (385 faces)
  [Ground] Ground_Sand  (385 faces)
  [Slopes] Slope_Straight  (385 faces)
  [Slopes] Slope_Corner_Out  (385 faces)
  [Slopes] Slope_Corner_In  (385 faces)
  [Cliffs] Cliff_Edge_A  (385 faces)
  [Cliffs] Cliff_Corner_Out_A  (385 faces)
  [Cliffs] Cliff_Corner_In_A  (385 faces)
  [Cliffs] Plateau_Grass  (385 faces)
  [Rivers] River_Straight  (385 faces)
  [Rivers] River_Bend  (385 faces)
  [Water] Water_Full  (385 faces)
  [Water] Water_Shore_Edge  (385 faces)
  [Paths] Path_Straight  (385 faces)
  [Paths] Path_Bend  (385 faces)
  [Roads] Road_Straight  (385 faces)
  [Roads] Road_Bend  (385 faces)
  [Bridges] Bridge_Wood  (926 faces)
  [Trees] Tree_Pine_A  (40 faces)
  [Trees] Tree_Oak_A  (104 faces)
  [Trees] Tree_Birch_A  (104 faces)
  [Plants] Bush_A  (60 faces)
  [Rocks] Rock_A  (20 faces)
  [Rocks] Rock_B  (20 faces)
  [Rocks] Rock_Small_A  (20 faces)
  [Plants] Grass_Tuft_A  (36 faces)
  [Props] Fence_Wood_Straight  (130 faces)
  [Props] Campfire  (230 faces)

LICENSE
  See LICENSE.txt. You may use these assets in personal and commercial projects.
  You may not resell or redistribute the assets themselves, even modified.
